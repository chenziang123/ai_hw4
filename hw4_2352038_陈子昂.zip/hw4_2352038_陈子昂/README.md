# Comparing Language Models' Chinese Semantic Understanding
A comparative analysis of various language models in understanding Chinese semantics
语言模型对理解中文语义的分析比较，附有使用截图和比较说明文档
